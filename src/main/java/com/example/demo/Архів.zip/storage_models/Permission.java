package com.example.demo.model.type;

public enum Permission {
    VIEW_ADMIN,
    VIEW_USER,

} 